# CS506 Midterm

The final Jupyter notebook is called Logistic_reg_full.ipynb

The submission CSV with the highest accuracy score is submission_highest.csv

The Exploration.ipynb notebook contains all of the prelimianry exploration I did on the data. it is disorganized but has somee nice visualizations that I was unable to include in my final report unfortunately. 

I wanted to include the Pickled version of my prediction model, but it was over 5GB so I could not upload it to github


Here are some graphs that I could not include in my final report because it would have made it too long but they're nice graphs so please look at them :) 

![alt text](https://github.com/CS506-Boston-University/midterm-Kercho0/blob/master/img/high.png)

![alt text](https://github.com/CS506-Boston-University/midterm-Kercho0/blob/master/img/med.png)


![alt text](https://github.com/CS506-Boston-University/midterm-Kercho0/blob/master/img/low.png)




